<?php

return [
    'avaliable_locales' => [['locale' => 'en', 'name' => 'English'], ['locale' => 'hr', 'name' => 'Croatian']]
];